#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import scipy.stats as stats
from math import sqrt
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')


# ## About the DataSet
# #### The car company wants to enter a new market and needs an estimation of exactly which variables affect the car prices.
# 
# - The goal is:
# 
#     - Which variables are significant in predicting the price of a car
#     - How well do those variables describe the price of a car

# In[2]:


filepath = r"D:\Data Science\Data Sets\Practise Data Sets\Multiple Linear Regression\scrap price.csv"

df = pd.read_csv(filepath)


# #### Exploring the Dataset

# In[3]:


df.head(10)


# In[4]:


df.shape


# In[5]:


df.describe()


# In[6]:


df.info()


# In[7]:


df[df.duplicated()]


# #### There are no null or duplicated data points.

# ## Checking for Outliers

# In[8]:


# num_columns = ['wheelbase', 'carlength', 'carwidth', 'carheight', 'curbweight', 'enginesize', 'boreratio', 'stroke', 
#                'compressionratio', 'horsepower', 'peakrpm', 'citympg', 'highwaympg']

# plt.figure(figsize=(8,15))

# for i, column in enumerate(num_columns, start=1):
#     plt.subplot(int(len(num_columns)/2), 3, i)
#     sns.boxplot(y=df[column], color='c')
    
# plt.tight_layout()


# ## Target Variable 'price'

# In[9]:


plt.figure(figsize=(4,6))
sns.boxplot(y=df['price'])
plt.show()


# In[10]:


plt.figure(figsize=(8,5))

sns.distplot(df['price'], bins=30)
sns.rugplot(df['price'],height=0.05)

price_mean = round(np.mean(df['price']),2)
price_median = round(np.median(df['price']),2)
price_std = round(np.std(df['price']),2)


plt.axvline(x=np.mean(df['price']), linestyle='--', color='r', label=f'mean: {price_mean}')
plt.axvline(x=np.median(df['price']), linestyle='--', color='c', label=f'median: {price_median}')
plt.axvline(x=np.std(df['price']), linestyle='--', color='purple', label=f'std: {price_std}')

plt.legend()
plt.show()


# #### We can observe that:
# - The average selling price of cars of USD 13276.71 with a standard deviation of USD 7969.34 
# 
# #### Positively Skewed
# - From the above visualization we can observe that the price distribution is positively skewed meaning most selling cars have a lower price and fewer cars have a higher selling price.
# - The presence of outliers has caused the mean price to be higher than the median, since mean is affected by outliers and median is not to some extent, hence in this dataset median provides a better measure for the central tendancy.

# In[11]:


plt.figure(figsize=(12,9))

Corr_mat = df.corr()
mask=np.triu(np.ones_like(Corr_mat))
sns.heatmap(Corr_mat, annot=True, cmap='coolwarm',mask=mask)
# sns.heatmap(data=df.corr(), annot=True, fmt='.2', cmap='coolwarm', square=True,)

plt.tight_layout
plt.show()


# We can see a few columns have a fairly strong relationship with our target variable, we can further dive into those features.
# 
# 1. Car Length
# 2. Car Width
# 3. Curb Weight
# 4. Engine Size
# 5. Horse Power
# 6. City Mpg
# 7. Highway Mpg

# In[12]:


features = ['carlength', 'carwidth', 'curbweight', 'enginesize', 'horsepower', 'citympg', 'highwaympg']
        
plt.figure(figsize=(8,8))
    
for i, column in enumerate(features, start=1):
    plt.subplot(4,2,i)
    sns.distplot(x=df[column])
    plt.xlabel(column)
    
plt.tight_layout()
plt.show()


# In[13]:


plt.figure(figsize=(8,8))
    
for i, column in enumerate(features, start=1):
    plt.subplot(4,2,i)
    sns.scatterplot(x=df[column], y=df['price'])
    plt.xlabel(column)
    
plt.tight_layout()
plt.show()


# ### From the above we can see the price has a positive relationship with all the features except City mpg and Highway mpg

# ### Exploring Categorical Variables

# In[14]:


cat_cols = df.select_dtypes(include=['object']).columns
cat_cols = cat_cols[1:]
cat_cols


# In[15]:


for i, col in enumerate(cat_cols):
    print(f'{col.title()}: {df[col].unique()}')


# In[16]:


df.columns


# In[17]:


palette = 'muted'

fig, axes = plt.subplots(figsize=(10,25), ncols=2, nrows=9)

sns.countplot(data=df, y='fueltypes', ax=axes[0,0], palette=palette)
sns.swarmplot(data=df, x='fueltypes', y='price', ax=axes[0,1], palette=palette)

sns.countplot(data=df, y='aspiration', ax=axes[1,0], palette=palette)
sns.swarmplot(data=df, x='aspiration', y='price', ax=axes[1,1], palette=palette)

sns.countplot(data=df, y='doornumbers', ax=axes[2,0], palette=palette)
sns.swarmplot(data=df, x='doornumbers', y='price', ax=axes[2,1], palette=palette)

sns.countplot(data=df, y='carbody', ax=axes[3,0], palette=palette)
sns.swarmplot(data=df, x='carbody', y='price', ax=axes[3,1], palette=palette)

sns.countplot(data=df, y='drivewheels', ax=axes[4,0], palette=palette)
sns.swarmplot(data=df, x='drivewheels', y='price', ax=axes[4,1], palette=palette)

sns.countplot(data=df, y='enginelocation', ax=axes[5,0], palette=palette)
sns.swarmplot(data=df, x='enginelocation', y='price', ax=axes[5,1], palette=palette)

sns.countplot(data=df, y='enginetype', ax=axes[6,0], palette=palette)
sns.swarmplot(data=df, x='enginetype', y='price', ax=axes[6,1], palette=palette)

sns.countplot(data=df, y='cylindernumber', ax=axes[7,0], palette=palette)
sns.swarmplot(data=df, x='cylindernumber', y='price', ax=axes[7,1], palette=palette)

sns.countplot(data=df, y='fuelsystem', ax=axes[8,0], palette=palette)
sns.swarmplot(data=df, x='fuelsystem', y='price', ax=axes[8,1], palette=palette)

plt.tight_layout()


# #### From the above we can see:
# 
# 1. People prefer to buy cars running on `gas` over diesel, thus:
#     - The fuel system `MPFI` has the largest count among other fuel systems, since it is used in cars run by `gas`
# 
# 2. People prefer Sedans (the highest) and Hatchbacks (second highest) which are family cars, thus we can also observe:
#     - The door number count of `4` is also the highest.
#     - The `front` engine location is also the highest.
# 3. Since most cars have a 4 or a 6 cylinders:
#     - We can see that the cars having `4` cylinder has the highest count.

# ## Statistical Testing

# #### Is average horsepower of sedans here a good representation of the sedans overall?
# 
# - Averge Sedans range from 150-300 horsepower, taking an average here: 225
# 
# - Source: https://medium.com/@wiack/what-is-a-good-amount-of-horsepower-for-a-car-f8c815906d20#:~:text=Sedans,between%20150%20to%20300%20horsepower.
# 
# 
# #### I'll be conducting a 1 sample two tailed t-test

# In[18]:


# Formulating the Hypothesis
Ho: "The average horsepower of sedans in this dataset is the same as the average horsepower of all sedans"
Ha: "The average horsepower of sedans in this dataset is different as the average horsepower of all sedans"

# Defining the alpha
alpha=0.05

# Filtering relevant data
sedan_hp = df[df['carbody']=='sedan']['horsepower']

tcal, pval = stats.ttest_1samp(a=sedan_hp, popmean=225)

print(f"T calculated: {tcal}")
print(f"P value: {pval}")
print('-------------------------------')


if pval<alpha:
    print("The average horsepower of sedans in this dataset is different as the average horsepower of all sedans.")
else:
    print("The average horsepower of sedans in this dataset is the same as the average horsepower of all sedans.")


# In[19]:


lower_tcri = stats.t.ppf(q=0.025,df=95)

if tcal<lower_tcri:
    print("The average horsepower of sedans in this dataset is different as the average horsepower of all sedans.")
else:
    print("The average horsepower of sedans in this dataset is the same as the average horsepower of all sedans.")


# In[20]:


se = np.std(sedan_hp)/sqrt(len(sedan_hp))

lower_range, upper_range = stats.t.interval(confidence=0.95, loc=np.mean(sedan_hp), scale=se, df=95)

print(f"The sample mean lies in between: {round(lower_range,2)}hp & {round(upper_range,2)}hp ")


# ### Based on the test conducted above, we can conclude that the sedans in this data do not represent accurate detail about the horsepower of sedans in general.

# ## Building a  Muliple Linear Regression Model

# In[21]:


# input features
X = df[['carlength', 'carwidth', 'curbweight', 'enginesize', 'horsepower']]

# target variable
y = df['price']


# In[22]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error 

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=100)

print(f"X_train shape: {X_train.shape}")
print(f"X_test shape: {X_test.shape}")
print(f"y_train shape: {y_train.shape}")
print(f"y_test shape: {X_test.shape}")


# In[23]:


lr = LinearRegression()

model = lr.fit(X_train, y_train)
mse = model.score(X_train, y_train)

print(f"Intercept(bias): {round(model.intercept_,2)}")
print(f"Coefficient(weight): {np.round(model.coef_,2)}")
print(f"Mean Squared Error: {round(mse,2)}")


# In[24]:


y_pred = model.predict(X_test)

pred_df = pd.DataFrame(y_pred, columns=['Predicted Price'])


# In[25]:


actual_price = pd.DataFrame(y_test)
actual_price.rename(columns={'price': 'Actual Price'}, inplace=True)
actual_price.reset_index(drop=True, inplace=True)


# In[26]:


comparison_df = pd.concat([pred_df, actual_price], axis=1)
comparison_df


# In[ ]:




