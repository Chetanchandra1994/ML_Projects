#!/usr/bin/env python
# coding: utf-8

# # Statistical Analysis of Mcdonalds Data
# 
# #### Aim of the study:
# - To find out wheter:
#     - Q1. As Serving Size increases do the calories in the food also increase?
#     - Q2. Is the average Protein Content in 2 categories of food (Chicken/Fish and Beef/Pork) same or different?
# 
# ### Lastly building a Linear Regression Model which predicts the Total Fat present in a food content based on it's Calories.

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import math
import warnings
warnings.filterwarnings('ignore')


# In[2]:


file_path = r"D:\Data Science\Data Sets\Practise Data Sets\McD_Data.csv"
df = pd.read_csv(file_path)
df.head(10)


# In[3]:


df.describe()


# In[4]:


df.info()


# In[5]:


df.shape


# #### Checking For Null and Duplicated Values

# In[6]:


df.isnull().sum()


# In[7]:


df[df.duplicated()]


# We can see there are no null and duplicated values

# #### Filtering out Serving Size and Calories to see if they have a relationshiup

# In[8]:


plt.figure(figsize=(10,10))
sns.heatmap(data=df.corr(), annot=True, fmt=".1f", cmap='coolwarm')


# #### From the above heatmap, there a a few variables that might have a potential relationship.
# 
# 1. Calories and Protein (0.8)
# 2. Calories and Carbohydrates (0.8)
# 3. Calories and Total Fat (0.9)
# 4. Calories and Serving Size

# #### Exploring the relationship between Serving Size and Calories

# In[9]:


df['Serving Size'].unique()


# In[10]:


x_data = df['Serving Size'].str.extract(r'(\d+(?:\.\d+)?)').astype(float)[0]
y_data = df['Calories']

# naming the series
x_data = pd.Series(x_data, name='Serving Size')


# In[11]:


sns.scatterplot(x=x_data, y=y_data)

plt.xlabel('Serving Size', fontsize=15)
plt.ylabel('Calories', fontsize=15)
plt.show()


# In[12]:


df1 = pd.DataFrame(data={'Serving Size': x_data, 'Calories': y_data})


# In[13]:


df1


# In[14]:


df1.corr()


# ### From the above visualization and correlation analysis
# - We can interpret there isn't a strong relationship between Serving Size and Calories, let's try some different columns.

# ## Hypothesis Testing
# 
# - Checking whether the average protein content is the same in Chicken & Fish and Beef & Pork

# #### Two tailed independent t-test

# In[15]:


# Hypothesis Formulation

Ho = 'The average protein in Chicken_Fish and Beef_Pork are the same'
Ha = 'The average protein in Chicken_Fish and Beef_Pork are different'

# Extracting the relevant data
chick_fsh = df[df['Category']=='Chicken & Fish']['Protein']
beef_prk = df[df['Category']=='Beef & Pork']['Protein']

# Checking to see if both categories have the same amount of datapoints
print(f"Data points in chicken and fish: {len(chick_fsh)}")
print(f"Data points in beef and pork: {len(beef_prk)}")


# In[16]:


# Taking the first 15 datapoints from chicken and fish to level the datapoints.
chick_fsh = chick_fsh[:15]

# Stating the alpha
alpha=0.05

tcal, pval = stats.ttest_ind(a=chick_fsh, b=beef_prk, equal_var=False)
# pval calculated is for both sides
# tcal calculated is for one side, the sign defines which side

if pval<alpha:
    print('''There is sufficient statistical evidence to reject the Ho.
This means, Chicken/Fish and Beef/Pork have different protein content on average.\n''')
else:
    print('''There is sufficient statistical evidence to fail to reject the Ho.
This means, Chicken/Fish and Beef/Pork have same protein content on average.\n''')
    
print(f"P value: {pval}")
print(f"T calculated: {tcal}")


# In[17]:


# Calculating t-critical and concluding the result

# tcri corresponds to the quantile that's mentioned
lower_tcri = stats.t.ppf(q=0.025, df=28)

if tcal<lower_tcri:
    print('''There is sufficient statistical evidence to reject the Ho.
This means, Chicken/Fish and Beef/Pork have different protein content on average.\n''')
else:
    print('''There is sufficient statistical evidence to fail to reject the Ho.
This means, Chicken/Fish and Beef/Pork have same protein content on average.\n''')


# In[18]:


# Calculating the standard error for the 2 categories
se_chck = chick_fsh.std()/math.sqrt(len(chick_fsh))
se_beef = beef_prk.std()/math.sqrt(len(beef_prk))

# Calculating the confidence interval for the 2 categories
lower_chck, upper_chck = stats.t.interval(alpha=0.95, loc=chick_fsh.mean(), scale=se_chck, df=14)
lower_beef, upper_beef = stats.t.interval(alpha=0.95, loc=beef_prk.mean(), scale=se_beef, df=14)

print("We can say we 95% confidence that: ")
print('-------------------------------------')
print(f'The mean protein of Chicken/Fish lies between: {round(lower_chck,2)}g and {round(upper_chck,2)}g\n'
      '-------------------------------------\n'
      f'The mean protein of Beef/Pork lies between: {round(lower_beef,2)}g and {round(upper_beef,2)}g')


# ### Building a Linear Regression model off of `Calories` and `Total Fat`
# 
# - Since there is a strong correlation between them - 0.904

# In[19]:


calories = df['Calories']
total_fat = df['Total Fat']


# ### Visualizing the relationship between Calories and Total Fat

# In[20]:


sns.scatterplot(x=calories, y=total_fat)

plt.title("Relation between Calories and Total Fat")
plt.xlabel('Calories', fontsize=15)
plt.ylabel('Total Fat', fontsize=15)
plt.grid(True)
plt.show()


# In[21]:


# Importing necessary libraries

from sklearn.linear_model import LinearRegression
lr = LinearRegression()

# Reshaping my dataset
x_train = np.array(calories).reshape(-1,1)
y_train = total_fat

# Fitting the model
model = lr.fit(x_train,y_train)

weight = model.coef_
bias = model.intercept_

print(f"Weight is: {weight[0]}")
print(f"Bias is: {bias}")


# #### Predicting the Model

# In[22]:


y_pred = lr.predict(x_train)
y_pred


# ### Plotting the Model

# In[23]:


# Plotting the actual data
sns.scatterplot(x=calories, y=total_fat, label='Actual Data')

# Plotting the prediction
sns.lineplot(x=calories, y=y_pred, label='Prediction', c='r', linestyle='--')

plt.title("Predicting Calories and Total Fat Relationship")
plt.grid(True)
plt.show()


# In[24]:


# Plotting the actual data
sns.lineplot(x=calories, y=total_fat, label='Actual Data')

# Plotting the prediction
sns.lineplot(x=calories, y=y_pred, label='Prediction', c='r', linestyle='--')

plt.title("Predicting Calories and Total Fat Relationship")
plt.grid(True)
plt.show()

